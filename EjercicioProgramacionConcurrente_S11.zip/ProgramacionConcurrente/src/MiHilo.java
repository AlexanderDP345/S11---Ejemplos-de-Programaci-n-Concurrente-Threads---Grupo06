
class MiHilo extends Thread {
    @Override
    public void run() {
        System.out.println("Este hilo es secundario.");
    }
}
