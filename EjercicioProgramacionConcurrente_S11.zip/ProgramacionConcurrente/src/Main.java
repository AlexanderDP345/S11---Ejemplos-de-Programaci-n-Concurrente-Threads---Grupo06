
public class Main {
    public static void main(String[] args) {
        //instancia de tipo thread, que se le asigna una referencia del hilo que utiliza el método main
        Thread hiloPrincipal = Thread.currentThread();
        
        // uso del método getName() para obtener el nombre por default del hilo principal
        System.out.println("EL nombre del hilo principal es: " + hiloPrincipal.getName());
        
        // Cambio de nombre e impresión en la consola 
        hiloPrincipal.setName("nuevo nombre");
        System.out.println("EL nuevo nombre del hilo principal es: " + hiloPrincipal.getName());
        
        // Obteniendo e imprimiendo la prioridad del hilo principal
        System.out.println("La prioridad del hilo principal es: " + hiloPrincipal.getPriority());
        
        // Establecemos la prioridad del hilo principal en MAX(10)
        System.out.println("Estableciendo la prioridad del hilo principal a la máxima o MAX (10)");
        hiloPrincipal.setPriority(Thread.MAX_PRIORITY);
        
        //Se muestra en consola la nueva prioridad del hilo principal
        System.out.println("La nueva prioridad del hilo principal es: " + hiloPrincipal.getPriority());
        
        /* Instanciamos un objeto de la clase miHilo para demostrar el uso de hilos
        MiHilo miHilo = new MyThread();
        miHilo.start();
        */
    }
}
